#include "../include/DenseLayer.h"
#include <cmath>

// -------------------- DenseLayer Constructor --------------------
DenseLayer::DenseLayer(size_t inputSize, size_t neurons, std::shared_ptr<ActivationFunction> activationFunc)
    : Layer(neurons), weights(neurons, inputSize), biases(neurons, 1), activation(std::move(activationFunc)) {
    weights.randomize(-1.0f, 1.0f);
    biases.randomize(-1.0f, 1.0f);
}

// -------------------- Forward Propagation --------------------
Matrix DenseLayer::forward(const Matrix& input) {
    Matrix weightedSum = weights.multiply(input, false) + biases;  // W * X + B
    return activation->apply(weightedSum);  // Apply activation function
}

// -------------------- Set Weights --------------------
void DenseLayer::setWeights(const Matrix& w) {
    if (w.getRows() != weights.getRows() || w.getCols() != weights.getCols()) {
        throw std::invalid_argument("Weight matrix dimensions do not match.");
    }
    weights = w;
}

// -------------------- Set Biases --------------------
void DenseLayer::setBiases(const Matrix& b) {
    if (b.getRows() != biases.getRows() || b.getCols() != biases.getCols()) {
        throw std::invalid_argument("Bias matrix dimensions do not match.");
    }
    biases = b;
}

