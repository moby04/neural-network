#ifndef LAYER_H
#define LAYER_H

#include "Matrix.h"


// Abstract Base Class for Layers
class Layer {
protected:
    size_t neuronCount;  // Number of neurons in this layer

public:
    explicit Layer(size_t neurons) : neuronCount(neurons) {}

    virtual ~Layer() = default;

    virtual Matrix forward(const Matrix& input) = 0;  // Pure virtual function
    size_t getNeuronCount() const { return neuronCount; }
};

#endif