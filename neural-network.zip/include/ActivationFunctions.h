#ifndef ACTIVATION_FUNCTIONS_H
#define ACTIVATION_FUNCTIONS_H

#include "Matrix.h"
#include <functional>

// Activation Function Base Class
class ActivationFunction {
    public:
        virtual ~ActivationFunction() = default;
        virtual Matrix apply(const Matrix& input) const = 0;
};

// Intermediate abstract classes
class SigmoidBasedActivation : public ActivationFunction {
    public:
        virtual ~SigmoidBasedActivation() = default;
};
    
// Base class for all ReLU-like activations
class ReLUBasedActivation : public ActivationFunction {
    public:
        virtual ~ReLUBasedActivation() = default;
};
    
// Base class for all Tanh-like activations
class TanhBasedActivation : public ActivationFunction {
    public:
        virtual ~TanhBasedActivation() = default;
};

// Concrete derived Activation Functions
// Sigmoid Activation Function
class SigmoidActivation : public SigmoidBasedActivation {
    public:
        Matrix apply(const Matrix& input) const override; 
};

// Swish Activation Function (variant of sigmoid)
class SwishActivation : public SigmoidBasedActivation {
    public:
        Matrix apply(const Matrix& input) const override;
};

// ReLU Activation Function
class ReLUActivation : public ReLUBasedActivation {
    public:
        Matrix apply(const Matrix& input) const override;
};

// Leaky ReLU Activation Function
class LeakyReLUActivation : public ReLUBasedActivation {
    public:
        Matrix apply(const Matrix& input) const override;
};

// Tanh Activation Function
class TanhActivation : public TanhBasedActivation {
    public:
        Matrix apply(const Matrix& input) const override;
};

// Hard Tanh Activation Function
class HardTanhActivation : public TanhBasedActivation {
    public:
        Matrix apply(const Matrix& input) const override;
};
#endif