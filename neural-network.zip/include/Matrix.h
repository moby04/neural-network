#ifndef MATRIX_H
#define MATRIX_H

#include <iostream>
#include <vector>
#include <string>
#include <compare>
#include <functional>

class Matrix {
public:
    Matrix(size_t rows, size_t cols, const std::string& name = "UNNAMED");
    ~Matrix();

    void setName(const std::string& name);
    std::string getName() const;

    void fillByHand();
    void print() const;
    void randomize(float min = 0.0f, float max = 1.0f);
    Matrix applyFunction(const std::function<float(float)>& func) const;

    static Matrix createIdentityMatrix(size_t size, const std::string& name = "UNNAMED");

    // Matrix operations
    Matrix add(const Matrix& other) const;
    Matrix subtract(const Matrix& other) const;
    Matrix multiply(const Matrix& other, bool elementWise = true) const;
    Matrix multiply(float scalar) const;
    Matrix transpose() const;

    // Getters
    size_t getRows() const;
    size_t getCols() const;
    const std::vector<std::vector<float>>& getData() const;

    // Setters
    void setData(const std::vector<std::vector<float>>& newData);

    // Friend functions for overloading the << and >> operators
    friend std::ostream& operator<<(std::ostream& os, const Matrix& matrix);
    friend std::istream& operator>>(std::istream& is, Matrix& matrix);

    // Overloaded operators
    Matrix operator+(const Matrix& other) const;
    Matrix operator-(const Matrix& other) const;
    Matrix operator*(const Matrix& other) const;
    Matrix operator*(float scalar) const;
    bool operator==(const Matrix& other) const;
    std::partial_ordering operator<=>(const Matrix& other) const;

    // Custom comparison function
    bool isEqual(const Matrix& other, float tolerance = 1e-5) const;

private:
    std::string name;
    size_t rows;
    size_t cols;
    std::vector<std::vector<float>> data;
};

#endif // MATRIX_H
